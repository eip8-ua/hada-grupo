﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace Library
{
    class CADLocker
    {
        public string constring;
        public SqlConnection connection;

        public CADLocker()
        {

        }
        public bool Create(ENLocker loc)
        {

        }
        public bool Delete(ENLocker loc)
        {

        }
        public bool Update(ENLocker loc)
        {

        }
        public bool Read(ENLocker loc)
        {

        }
    }
}
