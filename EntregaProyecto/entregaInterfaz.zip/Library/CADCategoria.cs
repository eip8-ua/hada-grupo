﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    class CADCategoria
    {
        public string constring;
        public SqlConnection connection;

        public CADCategoria()
        {

        }
        public bool Create(ENCategoria cat)
        {

        }
        public bool Delete(ENCategoria cat)
        {

        }
        public bool Update(ENCategoria cat)
        {

        }
        public bool Read(ENCategoria cat)
        {

        }
    }
}
