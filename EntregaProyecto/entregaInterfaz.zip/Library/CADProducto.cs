﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    class CADProducto
    {
        public string constring;
        public SqlConnection connection;

        public CADProducto()
        {

        }
        public bool Create(ENProducto prod)
        {

        }
        public bool Delete(ENProducto prod)
        {

        }
        public bool Update(ENProducto prod)
        {

        }
        public bool Read(ENProducto prod)
        {

        }
    }
}
