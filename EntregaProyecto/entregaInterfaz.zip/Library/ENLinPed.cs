﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    class ENLinPed
    {
        private int idLinPedido;
        private int idPedido;
        private int idProducto;
        private int cantidad;

        public bool Create()
        {

        }
        public bool Delete()
        {

        }
        public bool Update()
        {

        }
        public bool Read()
        {

        }
    }
}
