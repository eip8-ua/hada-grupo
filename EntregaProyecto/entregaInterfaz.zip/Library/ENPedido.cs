﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    class ENPedido
    {
        private int idPedido;
        private DateTime fechaPedido;

        public ENPedido()
        {

        }
        public bool Create()
        {

        }
        public bool Delete()
        {

        }
        public bool Update()
        {

        }
        public bool Read()
        {

        }
    }
}
