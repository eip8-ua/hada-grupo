INSERT INTO Usuario(dni, email, nombre, apellidos, tel�fono, fecha_nacimiento, admin?) VALUES ("123123456","pdc@email.com", "Pepe", " Domingo Casta�o", "883847575", "10/10/1950", 0),
INSERT INTO Usuario(dni, email, nombre, apellidos, tel�fono, fecha_nacimiento, admin?) VALUES ("123133456","rnp@email.com", "Rafael", " Nadal Parera", "883837575", "03/06/1989", 0),
INSERT INTO Usuario(dni, email, nombre, apellidos, tel�fono, fecha_nacimiento, admin?) VALUES ("123143456","lmp@email.com", "Lionel", "Momingo Pelelo", "883247575", "20/10/1980", 0),
INSERT INTO Usuario(dni, email, nombre, apellidos, tel�fono, fecha_nacimiento, admin?) VALUES ("123153456","nmc@email.com", "Nadia", " Malacute Contreras", "883147575", "01/10/1990", 0),
INSERT INTO Usuario(dni, email, nombre, apellidos, tel�fono, fecha_nacimiento, admin?) VALUES ("123163456","fnf@email.com", "Francesca", " Niso Franco", "883047575", "22/10/2000", 0),

INSERT INTO Direccion(calle, cod_postal, ciudad, provincia, pais) VALUES ("La Mancha" "03610", "Petrer", "Alicante", "Espa�a"),
INSERT INTO Direccion(calle, cod_postal, ciudad, provincia, pais) VALUES ("Mayor" "02811", "Alcornoque", "Pontevedra", "Espa�a"),
INSERT INTO Direccion(calle, cod_postal, ciudad, provincia, pais) VALUES ("Muralla 12" "14859", "�vila", "�vila", "Espa�a"),
INSERT INTO Direccion(calle, cod_postal, ciudad, provincia, pais) VALUES ("Brigadier Algarra" "03610", "Petrer", "Alicante", "Espa�a"),
INSERT INTO Direccion(calle, cod_postal, ciudad, provincia, pais) VALUES ("Banyeres" "29734", "Cadaqu�s", "Gerona", "Espa�a"),

INSERT INTO Locker(nombre) VALUES ("Kiosko Laura"),
INSERT INTO Locker(nombre) VALUES ("Casa Paquirr�n"),
INSERT INTO Locker(nombre) VALUES ("Panader�a Tomasa"),
INSERT INTO Locker(nombre) VALUES ("Habana"),

INSERT INTO Producto(nombre, pvp, url_image, descripcion, stock, popularidad) VALUES ("ASUS Vivobook Go", )